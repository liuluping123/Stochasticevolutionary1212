
% stochevolu.m
function dydt=stochevolu(t,y,varsigama,nu,sig1,sig2,dB)
dydt=zeros(2,1);
% dydt(1)=y(1)*(1-y(1))*(a*p*y(2)-c1); %dy/dt=x(1-x)(aPy-C1) a=0.6,p=1400,c1=500,c2=200;
% dydt(2)=y(2)*(1-y(2))*((1-a)*p*y(1)-c2);%dy/dt=y(1-y)((1-a)*Px-C2)


%%PD
dydt(1)=varsigama*nu*y(1)*(1-y(1))*(2-y(2)) -nu*y(1)*(1-y(1))*(log(y(1))-log(1-y(1)) ) + sig1*dB;
dydt(2)=varsigama*nu*y(2)*(1-y(2))*(-3-y(1))-nu*y(2)*(1-y(2))*(log(y(2))-log(1-y(2)) ) + sig2*dB;

% %%BoS
% dydt(1)=varsigama*nu*y(1)*(1-y(1))*(3*y(2)-1)-nu*y(1)*(1-y(1))*(log(y(1))-log(1-y(1)) ) + sig1*dB;
% dydt(2)=varsigama*nu*y(2)*(1-y(2))*(3*y(1)-2)-nu*y(2)*(1-y(2))*(log(y(2))-log(1-y(2)) ) + sig2*dB;


% % %%MP
% dydt(1)=varsigama*nu*y(1)*(1-y(1))*(2*y(2)-1)-nu*y(1)*(1-y(1))*(log(y(1))-log(1-y(1)) ) + sig1*dB;
% dydt(2)=varsigama*nu*y(2)*(1-y(2))*(-2*y(1)+1)-nu*y(2)*(1-y(2))*(log(y(2))-log(1-y(2)) ) + sig2*dB;


end
