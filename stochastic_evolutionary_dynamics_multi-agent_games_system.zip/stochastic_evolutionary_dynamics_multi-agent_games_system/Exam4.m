close all;
clear all;

nt = 10 * 40; % 迭代次数
Xt1=zeros(nt,1); % vector
Xt11=zeros(nt,1); 
Xt12=zeros(nt,1); 

Xt2=zeros(nt,1);
Xt21=zeros(nt,1);
Xt22=zeros(nt,1);

Xt3 = zeros(1, nt);
Xt31 = zeros(1, nt);
Xt32 = zeros(1, nt);
dt=1/nt;%迭代步长，可调
Xt1(1)=0.5;
Xt11(1)=0.5;
Xt12(1)=0.5;

Xt2(1)=0.5;
Xt21(1)=0.5;
Xt22(1)=0.5;

Xt3(1) = 0.5;
Xt31(1) = 0.5;
Xt32(1) = 0.5;

sig1 = 0.2;
sig2 =0.5; % 扰动大小
sig3 =1

%R1=10,R3=21,P=5,r=0.3,D=10,V1=20,V2=6,W1=4,W2=17,F=5,S=7,L=2,G=10,b=0.2,T=2,C=2,a=0.7;
R1=25,R3=17,P=8,r=0.5,D=8,V1=12,V2=7,W1=6,W2=8,F=15,S=16,L=5,G=18,b=0.5,T=7,C=6,a=0.6;


rng(123456789, 'twister');

for t = 2:nt
    dB = dt^0.5 * randn(1);
    Xt1(t) = Xt1(t - 1) + Xt1(t - 1) * (1 - Xt1(t - 1)) * (P - F + R1 + R3 - T - P*r - R3*Xt3(t) + T*Xt2(t) + T*Xt3(t) + D*b*Xt3(t) + D*Xt2(t)*Xt3(t) - T*Xt2(t)*Xt3(t) - D*b*Xt2(t)*Xt3(t)) * dt + sig1 * dB;
    Xt11(t) = Xt11(t - 1) + Xt11(t - 1) * (1 - Xt11(t - 1)) * (P - F + R1 + R3 - T - P*r - R3*Xt31(t) + T*Xt21(t) + T*Xt31(t) + D*b*Xt31(t) + D*Xt21(t)*Xt31(t) - T*Xt21(t)*Xt31(t) - D*b*Xt21(t)*Xt31(t)) * dt + sig2 * dB;
    Xt12(t) = Xt12(t - 1) + Xt12(t - 1) * (1 - Xt12(t - 1)) * (P - F + R1 + R3 - T - P*r - R3*Xt32(t) + T*Xt22(t) + T*Xt32(t) + D*b*Xt32(t) + D*Xt22(t)*Xt32(t) - T*Xt22(t)*Xt32(t) - D*b*Xt22(t)*Xt32(t)) * dt + sig3 * dB;

    Xt2(t) = Xt2(t - 1) + Xt2(t - 1) * (1 - Xt2(t - 1)) * (S - F - W1 + W2 + 2*F*a + D*Xt1(t) + D*Xt3(t) + P*r - D*b*Xt1(t) - D*b*Xt3(t) - 2*D*Xt1(t)*Xt3(t) + 2*D*b*Xt1(t)*Xt3(t)) * dt + sig1 * dB;
    Xt21(t) = Xt21(t - 1) + Xt21(t - 1) * (1 - Xt21(t - 1)) * (S - F - W1 + W2 + 2*F*a + D*Xt11(t) + D*Xt31(t) + P*r - D*b*Xt11(t) - D*b*Xt31(t) - 2*D*Xt11(t)*Xt31(t) + 2*D*b*Xt11(t)*Xt31(t)) * dt + sig2 * dB;
    Xt22(t) = Xt22(t - 1) + Xt22(t - 1) * (1 - Xt22(t - 1)) * (S - F - W1 + W2 + 2*F*a + D*Xt12(t) + D*Xt32(t) + P*r - D*b*Xt12(t) - D*b*Xt32(t) - 2*D*Xt12(t)*Xt32(t) + 2*D*b*Xt12(t)*Xt32(t)) * dt + sig3 * dB;

    Xt3(t) = Xt3(t - 1) + Xt3(t - 1) * (1 - Xt3(t - 1)) * (F - C + G - L - F*Xt1(t) + L*Xt1(t) + D*b*Xt1(t) + D*Xt1(t)*Xt2(t) + P*r*Xt1(t) - D*b*Xt1(t)*Xt2(t)) * dt + sig1 * dB;
    Xt31(t) = Xt31(t - 1) + Xt31(t - 1) * (1 - Xt31(t - 1)) * (F - C + G - L - F*Xt11(t) + L*Xt11(t) + D*b*Xt11(t) + D*Xt11(t)*Xt21(t) + P*r*Xt11(t) - D*b*Xt11(t)*Xt21(t)) * dt + sig2 * dB;
    Xt32(t) = Xt32(t - 1) + Xt32(t - 1) * (1 - Xt32(t - 1)) * (F - C + G - L - F*Xt12(t) + L*Xt12(t) + D*b*Xt12(t) + D*Xt12(t)*Xt22(t) + P*r*Xt12(t) - D*b*Xt12(t)*Xt22(t)) * dt + sig3 * dB;
    
    if Xt1(t)>1
       Xt1(t)=1;
   end
   if Xt11(t)>1
       Xt11(t)=1;
   end
    
   if Xt12(t)>1
       Xt12(t)=1;
   end
   
  if Xt1(t)<0
       Xt1(t)=0;
   end
   if Xt11(t)<0
       Xt11(t)=0;
   end 
    if Xt12(t)<0
       Xt12(t)=0;
    end 
   
   
   if Xt2(t)>1
       Xt2(t)=1;
   end
   if Xt21(t)>1
       Xt21(t)=1;
   end
   if Xt22(t)>1
       Xt22(t)=1;
   end
   
  if Xt2(t)<0
       Xt2(t)=0;
   end
   if Xt21(t)<0
       Xt21(t)=0;
   end 
    if Xt22(t)<0
       Xt22(t)=0;
    end
    if Xt3(t) > 1
        Xt3(t) = 1;
    end
 if Xt31(t) > 1
        Xt31(t) = 1;
 end
     if Xt32(t) > 1
        Xt32(t) = 1;
    end
    if Xt3(t) < 0
        Xt3(t) = 0;
    end

    if Xt31(t) < 0
        Xt31(t) = 0;
    end
    if Xt32(t) < 0
        Xt32(t) = 0;
    end
end

% 计算时间值
time_values = 0:dt:(nt - 1) * dt;

figure(1);
plot(time_values, Xt3);
hold on;
plot(time_values, Xt31);
hold on;
plot(time_values, Xt32);
xlabel('时间');
ylabel('选择概率');
legend('\sigma=0', '\sigma=0.5', '\sigma=1');
grid on;
