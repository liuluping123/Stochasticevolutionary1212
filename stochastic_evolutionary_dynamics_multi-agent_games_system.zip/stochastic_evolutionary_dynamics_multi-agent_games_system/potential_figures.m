clear all
set(groot,'defaultAxesTickLabelInterpreter','latex','defaulttextinterpreter','latex','defaultLegendInterpreter','latex');

% Generate a random potential of size n
% rng(2,'multFibonacci');
ns = [100 10 50 100];
epsilon = 1e-8;
T = [0 1 5];
t = length(T);

for k = 1:1% Generate k random instances
    n = ns(k);
    rng(1,'twister');
    P = randi(19,n);%9
    P(n,n) = 20;%10
    
    % Generate plots
    a = -15:0.2:15;
    b = a;
    % Generate two random vectors u,v
    [u,v] = random_directions(P);
    for i = 1:t
        plotential = compute_potential(u,v,a,b,P,T(i));
        fig = figure(t*(k-1)+i);
        fs = surfc(a,b,plotential);
        map = inferno;
        map = map(50:end,:);
        colormap(map);
        %clr   = [0.301 0.745 0.933]; %clr = [0.929 0.694 0.125]; %green 
        %clr = [0 0.447 0.741]; %blue
        fs(1).EdgeColor = '#006374'; %#e9967a ff8099 原#666666
        %fs(1).EdgeColor = 'none';
        %fs(1).FaceColor = clr;
        xlabel('$\varsigma_x$');
        ylabel('$\varsigma_y$');
        zlabel('Potential $\Phi^H$');
        %title(['$\varsigma = $ ' num2str(T(i))]);  
        %exportgraphics(fig,['figure_surface_appendix_' num2str(n) '_' num2str(T(i)) '.png'],'BackgroundColor','white','Resolution','400')
    end
end