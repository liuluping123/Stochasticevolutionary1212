function [u,v] = random_directions(P);

rng default
 n = size(P,1);
s1 = rand(1,n);
s1 = log(s1/s1(n));
t1 = rand(1,n);
t1 = log(t1/t1(n));
u  = [s1 t1];
s2 = rand(1,n);
s2 = log(s2/s2(n));
t2 = rand(1,n);
t2 = log(t2/t2(n));
v  = [s2 t2];

