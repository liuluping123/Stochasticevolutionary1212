
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%the 1st image
clc;clear;
%a=0.6,p=1400,c1=500,c2=200;
varsigama=12; nu=1;
sig1=0.1;
sig2=0.5;
dB =0.01; % randn(1);

figure(1)
% the 1st line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.1,0.6]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'rh-','linewidth',1,'markersize',6,'markerfacecolor','r','markerindices',points);
grid on
hold on 
set(gca,'XTick',[0:0.1:1],'YTick',[0:0.1:1])
axis([0 1 0 1])
% the 2nd line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.3,0.5]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'kx-','linewidth',1,'markersize',6,'markerindices',points);
hold on 
% the 3rd line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.1,0.9]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'bo-','linewidth',1,'markersize',6,'markerindices',points);
hold on 
% the 3-1rd line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.9,0.1]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'r*-','linewidth',1,'markersize',6,'markerindices',points);
hold on
% the 3-1rd line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.9,0.2]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'g*-','linewidth',1,'markersize',6,'markerindices',points);
hold on
% the 4th line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.4,0.9]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'gs-','linewidth',1,'markersize',6,'markerindices',points);
hold on 
% the 5th line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.7,0.2]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'md-','linewidth',1,'markersize',6,'markerindices',points);
hold on 
% the 5-1th line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.7,0.1]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'bp-','linewidth',1,'markersize',6,'markerindices',points);
hold on 
% the 6th line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.8,0.5]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'kp-','linewidth',1,'markersize',6,'markerfacecolor','k','markerindices',points);
hold on
% % the 7th line
% [t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu),[0,1],[0.75,0.3]);
% points=1:1:length(t);
% plot(y(:,1),y(:,2),'mh-','linewidth',1,'markersize',6,'markerfacecolor','k','markerindices',points);
% hold on
% the 8th line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.1,0.2]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'xg-','linewidth',1,'markersize',6,'markerfacecolor','k','markerindices',points);
hold on
% % the 9th line
% [t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu),[0,1],[0.1,0.95]);
% points=1:1:length(t);
% plot(y(:,1),y(:,2),'yd-','linewidth',1,'markersize',6,'markerfacecolor','k','markerindices',points);
% hold on
% the 9th line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.2,0.9]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'c+-','linewidth',1,'markersize',6,'markerfacecolor','k','markerindices',points);
hold on
% the 9th line
[t,y]=ode45(@(t,y) stochevolu(t,y,varsigama,nu,sig1,sig2,dB),[0,1],[0.9,0.5]);
points=1:1:length(t);
plot(y(:,1),y(:,2),'bh-','linewidth',1,'markersize',6,'markerfacecolor','k','markerindices',points);
hold on
xlabel('$x(t)$','interpreter','latex','Rotation',0);
ylabel('$y(t)~~~~$','interpreter','latex','Rotation',360);
title('Dynamic evolution process','FontWeight','bold');
