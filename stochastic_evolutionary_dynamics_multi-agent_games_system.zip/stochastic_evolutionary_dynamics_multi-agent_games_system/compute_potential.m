function p = compute_potential(u,v,a,b,P,T);

n  = size(P,2);
la = length(a);
lb = length(b);
p  = zeros(la,lb);

for i = 1:la;
    for j = 1:lb;
        transformed = a(i)*u+b(j)*v;
        x = exp(transformed(1:n));
        x = real(x/norm(x,1));
        y = exp(transformed(n+1:end));
        y = real(y/norm(y,1));
        p(i,j) = x*P*y'-T*sum(x.*log(x))-T*sum(y.*log(y));
    end
end
